#!/bin/bash

# Interactive Deployment Wizard for Autonomous Commerce Agent
# This script will guide you through the deployment process step-by-step

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

clear

echo -e "${CYAN}"
cat << "EOF"
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║     AUTONOMOUS COMMERCE AGENT - DEPLOYMENT WIZARD               ║
║                                                                  ║
║     This wizard will help you deploy your money-making agent    ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}\n"

# Function to print step headers
print_step() {
    echo -e "\n${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${PURPLE}  STEP $1: $2${NC}"
    echo -e "${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
}

print_info() {
    echo -e "${BLUE}ℹ${NC}  $1"
}

print_success() {
    echo -e "${GREEN}✓${NC}  $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC}  $1"
}

print_error() {
    echo -e "${RED}✗${NC}  $1"
}

# Step 1: Choose deployment method
print_step "1" "Choose Your Deployment Method"

echo -e "${CYAN}Select how you want to deploy:${NC}\n"
echo "  1) Local Development (Test on your computer - FREE)"
echo "  2) AWS EC2 (Recommended for production - ~\$5/month)"
echo "  3) DigitalOcean Droplet (Easy setup - \$6/month)"
echo "  4) Heroku (Easiest, managed - \$7/month)"
echo "  5) Google Cloud (Free tier available)"
echo "  6) Manual Setup (I'll guide you step-by-step)"
echo ""

read -p "Enter your choice (1-6): " deployment_choice

case $deployment_choice in
    1)
        DEPLOYMENT_TYPE="local"
        ;;
    2)
        DEPLOYMENT_TYPE="aws"
        ;;
    3)
        DEPLOYMENT_TYPE="digitalocean"
        ;;
    4)
        DEPLOYMENT_TYPE="heroku"
        ;;
    5)
        DEPLOYMENT_TYPE="gcp"
        ;;
    6)
        DEPLOYMENT_TYPE="manual"
        ;;
    *)
        print_error "Invalid choice. Exiting."
        exit 1
        ;;
esac

print_success "Selected: $DEPLOYMENT_TYPE deployment"

# Step 2: Check prerequisites
print_step "2" "Checking Prerequisites"

if [[ "$DEPLOYMENT_TYPE" == "local" ]]; then
    print_info "Checking local system..."
    
    # Check Python
    if command -v python3 &> /dev/null; then
        PYTHON_VERSION=$(python3 --version)
        print_success "Python installed: $PYTHON_VERSION"
    else
        print_error "Python 3 not found. Please install Python 3.9+"
        exit 1
    fi
    
    # Check pip
    if command -v pip3 &> /dev/null; then
        print_success "pip3 is available"
    else
        print_warning "pip3 not found. Installing..."
        python3 -m ensurepip --upgrade
    fi
fi

# Step 3: Get API keys
print_step "3" "API Keys Configuration"

echo -e "${YELLOW}You'll need the following API keys:${NC}\n"
echo "  ${GREEN}REQUIRED:${NC}"
echo "    1. Anthropic Claude API key (for AI content)"
echo "    2. At least 1 affiliate network (Amazon/Shopify/Hostinger)"
echo "    3. At least 1 social platform (Twitter/Telegram)"
echo ""
echo "  ${CYAN}OPTIONAL (can add later):${NC}"
echo "    - Additional affiliate networks"
echo "    - More social platforms"
echo "    - Analytics tools"
echo ""

print_info "Let's get your API keys..."
echo ""

# Get Claude API key
echo -e "${CYAN}1. Anthropic Claude API Key${NC}"
echo "   Get it from: https://console.anthropic.com/"
read -p "   Enter your Claude API key (or press Enter to skip): " CLAUDE_KEY
if [[ -z "$CLAUDE_KEY" ]]; then
    print_warning "Skipped - You'll need to add this later to .env file"
else
    print_success "Claude API key saved"
fi

# Affiliate network
echo ""
echo -e "${CYAN}2. Choose Your Primary Affiliate Network${NC}"
echo "   1) Shopify (Best: \$58-2000 per sale)"
echo "   2) Amazon (Wide selection: 4-10% commission)"
echo "   3) Hostinger (Easy: 60% commission)"
echo "   4) SEMrush (High value: \$200 per sale)"
echo "   5) Skip for now"
read -p "   Enter choice (1-5): " affiliate_choice

case $affiliate_choice in
    1)
        read -p "   Shopify Partner ID: " SHOPIFY_ID
        ;;
    2)
        read -p "   Amazon Access Key: " AMAZON_KEY
        read -p "   Amazon Secret Key: " AMAZON_SECRET
        read -p "   Amazon Partner Tag: " AMAZON_TAG
        ;;
    3)
        read -p "   Hostinger Affiliate ID: " HOSTINGER_ID
        ;;
    4)
        read -p "   SEMrush Affiliate ID: " SEMRUSH_ID
        ;;
esac

# Social platform
echo ""
echo -e "${CYAN}3. Choose Your Social Platform${NC}"
echo "   1) Twitter/X (Best reach)"
echo "   2) Telegram (Easiest, no limits)"
echo "   3) Skip for now"
read -p "   Enter choice (1-3): " social_choice

case $social_choice in
    1)
        read -p "   Twitter API Key: " TWITTER_KEY
        read -p "   Twitter API Secret: " TWITTER_SECRET
        read -p "   Twitter Access Token: " TWITTER_TOKEN
        read -p "   Twitter Access Secret: " TWITTER_TOKEN_SECRET
        ;;
    2)
        read -p "   Telegram Bot Token: " TELEGRAM_TOKEN
        read -p "   Telegram Channel ID: " TELEGRAM_CHANNEL
        ;;
esac

print_success "API keys collected!"

# Step 4: Create .env file
print_step "4" "Creating Configuration File"

cat > .env << EOF
# Autonomous Commerce Agent Configuration
# Generated by deployment wizard on $(date)

# ===== AI CONTENT GENERATION =====
ANTHROPIC_API_KEY=${CLAUDE_KEY:-your_key_here}

# ===== AFFILIATE NETWORKS =====
${SHOPIFY_ID:+SHOPIFY_PARTNER_ID=$SHOPIFY_ID}
${AMAZON_KEY:+AMAZON_ACCESS_KEY=$AMAZON_KEY}
${AMAZON_SECRET:+AMAZON_SECRET_KEY=$AMAZON_SECRET}
${AMAZON_TAG:+AMAZON_PARTNER_TAG=$AMAZON_TAG}
${HOSTINGER_ID:+HOSTINGER_AFFILIATE_ID=$HOSTINGER_ID}
${SEMRUSH_ID:+SEMRUSH_AFFILIATE_ID=$SEMRUSH_ID}

# Add these later:
# CJ_API_KEY=
# IMPACT_API_KEY=
# HUBSPOT_AFFILIATE_CODE=

# ===== SOCIAL MEDIA =====
${TWITTER_KEY:+TWITTER_API_KEY=$TWITTER_KEY}
${TWITTER_SECRET:+TWITTER_API_SECRET=$TWITTER_SECRET}
${TWITTER_TOKEN:+TWITTER_ACCESS_TOKEN=$TWITTER_TOKEN}
${TWITTER_TOKEN_SECRET:+TWITTER_ACCESS_SECRET=$TWITTER_TOKEN_SECRET}
${TELEGRAM_TOKEN:+TELEGRAM_BOT_TOKEN=$TELEGRAM_TOKEN}
${TELEGRAM_CHANNEL:+TELEGRAM_CHANNEL_ID=$TELEGRAM_CHANNEL}

# ===== WEBSITE =====
SITE_URL=https://yourdeals.com

# ===== AGENT CONFIGURATION =====
POSTS_PER_HOUR=2
OFFERS_TO_FETCH=20
MIN_COMMISSION_RATE=5.0
MIN_DISCOUNT_PERCENT=15.0
MIN_PRICE=10.0
MAX_PRICE=500.0

# ===== MONITORING (Optional) =====
# SLACK_WEBHOOK=
# ALERT_EMAIL=
# GA_ID=
EOF

print_success "Configuration file created: .env"
print_warning "Review and edit .env to add any missing keys"

# Step 5: Install dependencies
print_step "5" "Installing Dependencies"

if [[ "$DEPLOYMENT_TYPE" == "local" ]]; then
    print_info "Creating virtual environment..."
    python3 -m venv venv
    print_success "Virtual environment created"
    
    print_info "Activating virtual environment..."
    source venv/bin/activate
    
    print_info "Installing Python packages..."
    pip install -r requirements.txt
    print_success "All dependencies installed"
fi

# Step 6: Run tests
print_step "6" "Running Tests"

read -p "Run test suite now? (y/n): " run_tests

if [[ "$run_tests" == "y" ]]; then
    print_info "Running comprehensive tests..."
    if [[ "$DEPLOYMENT_TYPE" == "local" ]]; then
        source venv/bin/activate
    fi
    python test_agent.py || print_warning "Some tests failed - check your API keys"
fi

# Step 7: Deployment-specific instructions
print_step "7" "Deployment Instructions"

case $DEPLOYMENT_TYPE in
    "local")
        cat << EOF

${GREEN}═══════════════════════════════════════════════════════════${NC}
${GREEN}  LOCAL DEPLOYMENT READY!${NC}
${GREEN}═══════════════════════════════════════════════════════════${NC}

${CYAN}To start your agent:${NC}

  1. Activate the virtual environment:
     ${YELLOW}source venv/bin/activate${NC}

  2. Start the agent:
     ${YELLOW}python autonomous_agent.py${NC}

  3. Open dashboard in your browser:
     ${YELLOW}open dashboard.html${NC}

${CYAN}To keep it running 24/7:${NC}

  Option A - Using screen:
     ${YELLOW}screen -S agent${NC}
     ${YELLOW}python autonomous_agent.py${NC}
     Press Ctrl+A, then D to detach

  Option B - Using nohup:
     ${YELLOW}nohup python autonomous_agent.py > agent.log 2>&1 &${NC}

${CYAN}To view logs:${NC}
     ${YELLOW}tail -f agent.log${NC}

${CYAN}To stop the agent:${NC}
     Press Ctrl+C (or kill the process)

EOF
        ;;
    
    "aws")
        cat << EOF

${GREEN}═══════════════════════════════════════════════════════════${NC}
${GREEN}  AWS EC2 DEPLOYMENT${NC}
${GREEN}═══════════════════════════════════════════════════════════${NC}

${CYAN}Step 1: Launch EC2 Instance${NC}

  1. Go to AWS Console > EC2 > Launch Instance
  2. Choose:
     - AMI: Ubuntu Server 24.04 LTS
     - Instance Type: t2.micro (free tier)
     - Key Pair: Create or select existing
     - Security Group: Allow SSH (port 22)
  3. Launch and note the public IP

${CYAN}Step 2: Upload Files${NC}

  ${YELLOW}scp -i your-key.pem -r * ubuntu@YOUR_EC2_IP:~/agent/${NC}

${CYAN}Step 3: SSH and Setup${NC}

  ${YELLOW}ssh -i your-key.pem ubuntu@YOUR_EC2_IP${NC}
  ${YELLOW}cd ~/agent${NC}
  ${YELLOW}./deploy.sh${NC}

${CYAN}Step 4: Start Agent${NC}

  ${YELLOW}sudo systemctl start commerce-agent${NC}
  ${YELLOW}sudo systemctl status commerce-agent${NC}

${CYAN}View logs:${NC}
  ${YELLOW}tail -f ~/agent/logs/agent.log${NC}

${PURPLE}Cost: ~\$5-10/month${NC}

EOF
        ;;
    
    "digitalocean")
        cat << EOF

${GREEN}═══════════════════════════════════════════════════════════${NC}
${GREEN}  DIGITALOCEAN DEPLOYMENT${NC}
${GREEN}═══════════════════════════════════════════════════════════${NC}

${CYAN}Step 1: Create Droplet${NC}

  1. Go to DigitalOcean dashboard
  2. Click "Create" > "Droplets"
  3. Choose:
     - Image: Ubuntu 24.04 LTS
     - Plan: Basic \$6/month
     - Region: Closest to your audience
  4. Add SSH key
  5. Create Droplet

${CYAN}Step 2: Upload Files${NC}

  ${YELLOW}scp -r * root@YOUR_DROPLET_IP:~/agent/${NC}

${CYAN}Step 3: SSH and Setup${NC}

  ${YELLOW}ssh root@YOUR_DROPLET_IP${NC}
  ${YELLOW}cd ~/agent${NC}
  ${YELLOW}./deploy.sh${NC}

${CYAN}Step 4: Start Agent${NC}

  ${YELLOW}systemctl start commerce-agent${NC}
  ${YELLOW}systemctl status commerce-agent${NC}

${PURPLE}Cost: \$6/month${NC}

EOF
        ;;
    
    "heroku")
        cat << EOF

${GREEN}═══════════════════════════════════════════════════════════${NC}
${GREEN}  HEROKU DEPLOYMENT (EASIEST)${NC}
${GREEN}═══════════════════════════════════════════════════════════${NC}

${CYAN}Step 1: Install Heroku CLI${NC}

  ${YELLOW}brew tap heroku/brew && brew install heroku${NC}
  (or download from https://devcenter.heroku.com/articles/heroku-cli)

${CYAN}Step 2: Create Procfile${NC}

  ${YELLOW}echo "worker: python autonomous_agent.py" > Procfile${NC}

${CYAN}Step 3: Deploy${NC}

  ${YELLOW}heroku login${NC}
  ${YELLOW}git init${NC}
  ${YELLOW}git add .${NC}
  ${YELLOW}git commit -m "Initial deployment"${NC}
  ${YELLOW}heroku create your-agent-name${NC}
  ${YELLOW}git push heroku main${NC}

${CYAN}Step 4: Configure${NC}

  ${YELLOW}heroku config:set ANTHROPIC_API_KEY=your_key${NC}
  ${YELLOW}heroku config:set AMAZON_ACCESS_KEY=your_key${NC}
  (set all your .env variables)

${CYAN}Step 5: Scale${NC}

  ${YELLOW}heroku ps:scale worker=1${NC}

${CYAN}View logs:${NC}
  ${YELLOW}heroku logs --tail${NC}

${PURPLE}Cost: \$7/month${NC}

EOF
        ;;
esac

# Step 8: Final checklist
print_step "8" "Pre-Launch Checklist"

echo -e "${YELLOW}Before you start earning, verify:${NC}\n"
echo "  [ ] All API keys configured in .env"
echo "  [ ] At least 1 affiliate account approved"
echo "  [ ] At least 1 social media account ready"
echo "  [ ] Tests passed (or you understand the failures)"
echo "  [ ] Agent running (or deployment in progress)"
echo "  [ ] Can access dashboard.html"
echo "  [ ] Logs show successful cycles"
echo ""

read -p "Ready to launch? (y/n): " ready_to_launch

if [[ "$ready_to_launch" == "y" ]]; then
    print_step "🚀" "LAUNCHING YOUR AGENT!"
    
    if [[ "$DEPLOYMENT_TYPE" == "local" ]]; then
        print_info "Starting agent in background..."
        source venv/bin/activate
        nohup python autonomous_agent.py > agent.log 2>&1 &
        AGENT_PID=$!
        print_success "Agent started! PID: $AGENT_PID"
        print_info "View logs: tail -f agent.log"
    fi
    
    echo -e "\n${GREEN}${BOLD}"
    cat << "EOF"
    ╔══════════════════════════════════════════════════════════════╗
    ║                                                              ║
    ║              🎉 CONGRATULATIONS! 🎉                          ║
    ║                                                              ║
    ║     Your Autonomous Commerce Agent is now LIVE!             ║
    ║                                                              ║
    ║     Watch the money roll in! 💰                             ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}\n"
    
    echo -e "${CYAN}What happens next:${NC}"
    echo "  • Agent runs automatically every hour"
    echo "  • Fetches best deals from 7 affiliate networks"
    echo "  • Creates engaging content with AI"
    echo "  • Posts to your social media"
    echo "  • Creates landing pages"
    echo "  • Tracks clicks and revenue"
    echo ""
    echo -e "${YELLOW}Monitor your progress:${NC}"
    echo "  • Dashboard: open dashboard.html"
    echo "  • Logs: tail -f agent.log"
    echo "  • Stats: cat agent_stats.json"
    echo ""
    echo -e "${PURPLE}Expected timeline to \$10/hour:${NC}"
    echo "  • Month 1: \$100-300"
    echo "  • Month 2: \$400-700"
    echo "  • Month 3: \$800-1,200"
    echo "  • Month 4+: \$1,200+ (GOAL!)"
    echo ""
    echo -e "${GREEN}Good luck! 🚀${NC}"
    
else
    echo -e "\n${YELLOW}No problem! When you're ready:${NC}"
    echo "  1. Review your .env configuration"
    echo "  2. Run: python autonomous_agent.py"
    echo "  3. Watch the magic happen!"
fi

echo -e "\n${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
echo -e "${BLUE}Need help? Check these docs:${NC}"
echo "  • QUICKSTART.md - Fast start guide"
echo "  • DEPLOYMENT_GUIDE.md - Detailed deployment"
echo "  • SETUP_GUIDE.md - Complete setup"
echo ""
echo -e "${GREEN}Thank you for using Autonomous Commerce Agent!${NC}\n"
